package com.example.projetodesafio.models;

public class KitMasc extends Kit {

    public KitMasc() {
        this.setTipoKit(TipoKitEnum.MASC);
    }

}
