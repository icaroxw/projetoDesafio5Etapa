package com.example.projetodesafio.models;

public class KitFem extends Kit {

    public KitFem() {
        this.setTipoKit(TipoKitEnum.FEM);
    }

}
